READ AND AGREE !!!

don't reupload my script files !!!
don't sell my script files !!!
don't put my script files into your injector app !!!
if you still dare to steal or reupload my script, i will always consider it a debt that must be paid, because you took advantage of me.

just die from this world you stealer script and reuploader script

buy file porting if you want full sfx & voice / like original audio skin
discord server: https://discord.gg/AZUREZPsRx